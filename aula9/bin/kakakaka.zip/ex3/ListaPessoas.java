package ex3;

import java.util.ArrayList;
import java.util.LinkedList;

import ex3.VectorPessoas.VectorIterator;

public class ListaPessoas {
	private LinkedList<Pessoa> vector = new LinkedList<Pessoa>();
	
	public boolean addPessoa(Pessoa p){
		if(!vector.contains(p)){
			vector.add(p);
			return true;
		}
		return false;
	}
	
	public boolean removePessoa(Pessoa p){
		if(vector.contains(p)){
			vector.remove(p);
			return true;
		}
		return false;
	}
	public Pessoa[] toArray(){
		return (Pessoa[]) vector.toArray();
	}
	public int size(){
		return vector.size();
	}
	public class ListaIterador implements Iterator{
		private int i=0;
		private Pessoa p;
		public boolean hasNext(){
			return i<vector.size();
		}
		public Pessoa next(){
			if(hasNext()){
				i++;
				return vector.get(i-1);
			}
			throw new IndexOutOfBoundsException("only "+ vector.size() + " elements");
		}
		public void remove(){
			if(!vector.isEmpty()){
				vector.remove(p);
			}
		}
	}
	public Iterator iterator(){
		return new ListaIterador();
	}
	public String toString() {
		return iterator().next().toString();
	}
}


package ex3;

import java.util.ArrayList;

public class VectorPessoas  {
	private ArrayList<Pessoa> vector = new ArrayList<Pessoa>();
	
	public boolean addPessoa(Pessoa p){
		return vector.add(p);
	}
	
	public boolean removePessoa(Pessoa p){
			return vector.remove(p);
	}
	
	public int totalPessoas(){
		return vector.size();
	}
	public class VectorIterator implements Iterator{
		private int i=0;
		private Pessoa p;
		public boolean hasNext(){
			return i<vector.size();
		}
		public Pessoa next(){
			if(hasNext()){
				i++;
				return vector.get(i-1);
			}throw new IndexOutOfBoundsException("only "+ vector.size() + " elements");
		}
		public void remove(){
			if(vector.size()!=0){
				vector.remove(p);
			}
		}
	}
	public Iterator iterator(){
		return new VectorIterator();
	}

	@Override
	public String toString() {
		return iterator().next().toString();
	}
}